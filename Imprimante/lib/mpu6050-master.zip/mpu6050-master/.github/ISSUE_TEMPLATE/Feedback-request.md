---
name: "\U0001F408 Feddback or requests"
about: Suggest an idea or improvement for this project
title: 'ElectronicCats'
labels: 'enhancement'
---

**What idea or improvement for the library has occurred to you?**

**If you found an error:** 

Please describe clearly and concisely the problem you are aware of.


**Have you already found a solution?**

If you found a way to fix the problem please let us know.
It would be very helpful if you put the part of the code that needs to be corrected and how it needs to be corrected.

***Thanks a lot***